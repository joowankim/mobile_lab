/**
 * @author JooWan Kim
 * @brief  show fragments and provide buttons to change the image fragments
 */

package org.androidtown.lab3_3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    //declare objects
    public Button btn_frag1;
    public Button btn_frag2;

    FirstFragment firstFragment;
    SecondFragment secondFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        setListener();
    }

    /**
     * @brief initialize the objects
     */
    public void init(){
        btn_frag1 = findViewById(R.id.tab1);
        btn_frag2 = findViewById(R.id.tab2);

        firstFragment = new FirstFragment();
        secondFragment = new SecondFragment();
    }

    /**
     * @brief react to user's clicking buttons
     */
    public void setListener(){
        btn_frag1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //call the fragment_first
                getSupportFragmentManager().beginTransaction().replace(R.id.framelayout_for_fragment, firstFragment).commit();
            }
        });
        btn_frag2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //call the fragment_second
                getSupportFragmentManager().beginTransaction().replace(R.id.framelayout_for_fragment, secondFragment).commit();
            }
        });
    }

}
