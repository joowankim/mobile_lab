package org.androidtown.lab4_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    Button open;
    Button close;
    LinearLayout slideArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize views
        open = findViewById(R.id.open);
        close = findViewById(R.id.close);
        slideArea = findViewById(R.id.sliding);

        /**
         * @brief react to click button events
         */
        open.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ // take the green slide using open button
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate_left);
                slideArea.setVisibility(View.VISIBLE);
                slideArea.startAnimation(anim);
            }
        });

        close.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ // eliminate the green slide using close button
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate_right);
                slideArea.startAnimation(anim);
                slideArea.setVisibility(View.GONE);
            }
        });
    }
}
