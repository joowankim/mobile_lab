/**
 * @author JooWan Kim
 * @brief  show the information
 */

package org.androidtown.lab3_2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DataActivity extends AppCompatActivity {
    //declare objects
    Button btn;
    TextView name, gender, receiving;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        //initialize objects
        btn = findViewById(R.id.back);
        name = findViewById(R.id.name);
        gender = findViewById(R.id.gender);
        receiving = findViewById(R.id.receiving);

        //create intent and bundle to get intent from MainActivity
        Intent intent = getIntent();
        Bundle myBundle = intent.getExtras();

        //set the information on correct location
        name.setText(myBundle.getString("name"));
        gender.setText(myBundle.getString("gender"));
        receiving.setText(myBundle.getString("receive"));

        //return the intent
        btn.setOnClickListener(new View.OnClickListener(){
           @Override
            public void onClick(View v){
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                finish();
           }
        });
    }
}
