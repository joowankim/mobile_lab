/**
 * @author JooWan Kim
 * @brief  to send text message consisted by name and age to NewActivity
 * @date   2018.04.10
 */

package org.androidtown.lab2_1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText Name;
    EditText Age;
    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         * @brief to initialize texts and button
         */
        Name = findViewById(R.id.editText1);
        Age = findViewById(R.id.editText2);
        button1 = findViewById(R.id.btn);

        /**
         * @brief to react click situation to users
         * @param View.OnClickListener() to override onClick method
         */
        button1.setOnClickListener(new View.OnClickListener() {

            /**
             * @brief when user click the button, to set the reaction
             * @param view button
             */
            @Override
            public void onClick(View view) {
                String loginName = Name.getText().toString();
                String loginAge = Age.getText().toString();

                //to create a intent object
                Intent intent = new Intent(getApplicationContext(), NewActivity.class);
                intent.putExtra("loginName", loginName);    //put the name in intent
                intent.putExtra("loginAge", loginAge);      //put the age in intent
                startActivity(intent);  //to start NewActivity

            }


        });
    }
}
