/**
 * @author JooWan Kim
 * @brief  to send entered URL to newActivity, when users click NEXT button
 * @date   2018.04.10
 */

package org.androidtown.lab2_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText Url;
    Button nextBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //to initialize URL text and NEXT button
        Url = findViewById(R.id.editText);
        nextBtn = findViewById(R.id.btn);

        nextBtn.setOnClickListener(new View.OnClickListener(){

            //to react to users, when they click NEXT button
            @Override
            public void onClick(View view) {
                String myUrl = Url.getText().toString();
                //to create a intent to interact with newActivity
                Intent intent = new Intent(getApplicationContext(), newActivity.class);
                intent.putExtra("Url", myUrl);  //put the URL in intent
                startActivity(intent);      //to start newActivity
            }

        });
    }

}
