package org.androidtown.lab2_2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class newActivity extends AppCompatActivity {

    TextView textView;
    Button goBtn;
    Button backBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        //to initialize objects that include text view, go button and back button
        textView = findViewById(R.id.textView);
        goBtn = findViewById(R.id.goBtn);
        backBtn = findViewById(R.id.backBtn);

        //it uses final, because the URL must not be changed when users using this app
        final Intent passedIntent = getIntent();
        final String passedUrl = passedIntent.getStringExtra("Url");    //to get URL from the intent
        textView.setText(passedUrl);

        goBtn.setOnClickListener(new View.OnClickListener(){
            //to react to users who clicked GO button
            @Override
            public void onClick(View view) {
                //if passed URL is not blank, show the web page
                if (!passedUrl.isEmpty()) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://" + passedUrl));
                    startActivity(intent);
                } else {//else, float a toast message
                    Toast.makeText(getApplicationContext(), "주소를 다시 입력해주세요", Toast.LENGTH_LONG).show();
                }
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener(){
            //to react to users who clicked BACK button
            @Override
            public void onClick(View view){
                //when BACK button is clicked, float this toast message and finish this activity
                Toast.makeText(getApplicationContext(), "뒤로 가기를 눌렀습니다", Toast.LENGTH_LONG).show();
                finish();
            }
        });

    }
}
