package org.androidtown.lab5_2;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editText, editText2;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize each object
        editText = findViewById(R.id.editText);
        editText2 = findViewById(R.id.editText2);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                new pactoCalculate().execute();
            }
        });
    }

    private class pactoCalculate extends AsyncTask<Void, Integer, Void>{

        String msg = ""; // for float message on activity
        int n;           // input value
        int result;     // calculated value

        /**
         * @brief initialize each object for calculating
         */
        @Override
        protected void onPreExecute() {
            msg += editText.getText();  // get the number and convert the message to String
            n = Integer.parseInt(msg);   // convert the message to integer for calculate factorial
            result = n;                  // get the n!'s first number
            editText2.append(msg);      // float the message of the number
        }

        /**
         * @brief calculate factorial
         * @param params
         * @return
         */
        @Override
        protected Void doInBackground(Void... params){
            for(int i=1; i<n; i++) {
                try {
                    Thread.sleep(500);
                    publishProgress(n - i); // call onProgressUpdate() method
                    result *= n - i;
                } catch (Exception e) {}
            }
            return null;
        }

        /**
         * @brief float the message of the number
         * @param values brought by publishProgress() method
         */
        @Override
        protected void onProgressUpdate(Integer... values) {
            msg = " " + Integer.toString(values[0].intValue());
            editText2.append(msg);
        }

        /**
         * @brief print the result of factorial
         * @param aVoid
         */
        @Override
        protected void onPostExecute(Void aVoid){
            msg =  "\n =" + result;
            editText2.append(msg);
        }
    }

}
