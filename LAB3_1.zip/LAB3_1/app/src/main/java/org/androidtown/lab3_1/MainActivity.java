/**
 * @author JooWan Kim
 * @brief  change color of button's text
 */

package org.androidtown.lab3_1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

/**
 * @brief class of MainActivity
 */
public class MainActivity extends AppCompatActivity {
    Button myBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize button object
        myBtn = findViewById(R.id.btn);
        registerForContextMenu(myBtn);  //register for context menu
    }

    /**
     * @brief create context menu
     * @param menu built-in context menu
     * @param v main  activity
     * @param menuInfo  empty menu
     */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Button Menu");

        //add contents, specify the colors
        menu.add(0, Color.RED, 0, "Red");
        menu.add(0, Color.GREEN, 0, "Green");
        menu.add(0, Color.BLUE, 0, "Blue");
    }

    /**
     * @brief  get the selected item
     * @param  item selected item
     * @return boolean value
     */
    @Override
    public boolean onContextItemSelected(MenuItem item){
        //change the text of button
        myBtn.setTextColor(item.getItemId());
        return true;
    }
}