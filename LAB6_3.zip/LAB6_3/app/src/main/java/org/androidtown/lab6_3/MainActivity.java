package org.androidtown.lab6_3;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;
    MySQLiteOpenHelper helper;

    EditText stuName, stuNum;
    Button adding, deleting;

    ListView listView;

    String studentName, studentNumber;
    String[] info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // generate database
        helper = new MySQLiteOpenHelper(MainActivity.this, "student.db", null, 1);

        stuName = findViewById(R.id.name);
        stuNum = findViewById(R.id.number);
        adding = findViewById(R.id.add);
        deleting = findViewById(R.id.delete);
        listView = findViewById(R.id.listView);
        // show list
        invalidate();

        adding.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // get name and student number
                studentName = stuName.getText().toString();
                studentNumber = stuNum.getText().toString();

                if (!studentName.equals("") && !studentNumber.equals("")) {
                    insert(studentName, studentNumber);
                    invalidate();
                } else {    // if a user entered nothing
                    if (studentName.equals("")) Toast.makeText(getApplicationContext(), "please enter name", Toast.LENGTH_SHORT).show();
                    if (studentNumber.equals("")) Toast.makeText(getApplicationContext(), "please enter student number", Toast.LENGTH_SHORT).show();
                }
            }
        });

        deleting.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                studentName = stuName.getText().toString();
                if(!studentName.equals("")) { // when a user entered right name
                    delete(studentName);
                    invalidate();
                } else {    // if a user entered nothing
                    Toast.makeText(getApplicationContext(), "please enter name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * @brief insert name and student number into database
     * @param name     student name
     * @param number   student number
     */
    public void insert(String name, String number) {
        db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("number", number);
        db.insert("student", null, values);
    }

    /**
     * @brief delete studnet row
     * @param name  student name
     */
    public void delete(String name) {
        db = helper.getWritableDatabase();
        db.delete("student", "name=?", new String[]{name});
    }

    /**
     * @brief point each things in database
     */
    public void select(){

        db = helper.getReadableDatabase();
        Cursor c = db.query("student", null, null, null, null, null, null);
        // initialize info value using database cursor
        info = new String[c.getCount()];
        int count = 0;
        while(c.moveToNext()) {
            info[count] = c.getString(c.getColumnIndex("name")) + " " + c.getString(c.getColumnIndex("number"));
            count++;
        }
        c.close();
    }

    /**
     * @brief redraw list view
     */
    private void invalidate(){
        select();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, info);
        listView.setAdapter(adapter);
    }
}
