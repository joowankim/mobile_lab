/**
 * @author JooWan Kim
 * @brief  get and send information
 */

package org.androidtown.lab3_2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

/**
 * @brief class of MainActivity
 */
public class MainActivity extends AppCompatActivity {
    //declare objects and context
    EditText editText;
    RadioGroup radioGroup;
    CheckBox checkSMS, checkEmail;
    RadioButton radioMale, radioFemale;
    Button button;

    Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize context
        mContext = getApplicationContext();
        //initialize objects
        editText = findViewById(R.id.name);
        radioGroup = findViewById(R.id.gender);
        radioMale = findViewById(R.id.male);
        radioFemale = findViewById(R.id.female);
        checkSMS = findViewById(R.id.sms);
        checkEmail = findViewById(R.id.email);
        button = findViewById(R.id.register);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create intent and bundle to send the information to DataActivity
                Intent intent = new Intent(mContext, DataActivity.class);
                Bundle myBundle = new Bundle();
                //input the name
                myBundle.putString("name", ": " + editText.getText().toString());
                //input the gender
                int checkedID = radioGroup.getCheckedRadioButtonId();
                if(checkedID == radioMale.getId()) myBundle.putString("gender", ": 남");
                else if(checkedID == radioFemale.getId()) myBundle.putString("gender", ": 여");
                else myBundle.putString("gender", ": 성별을 선택하지 않았습니다");
                //input the selected items
                String msg = ":";
                if(checkSMS.isChecked()) msg += " SMS";
                if(checkEmail.isChecked()) msg += " e-mail";
                myBundle.putString("receive", msg);
                //put the bundle in intent
                intent.putExtras(myBundle);
                //show DataActivity
                startActivityForResult(intent, 1);
            }
        });
    }

    /**
     * @brief initialize the contents
     * @param data intent from DataActivity
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        editText.setText("");
        radioGroup.clearCheck();
        radioMale.setChecked(false);
        radioFemale.setChecked(false);
        checkSMS.setChecked(false);
        checkEmail.setChecked(false);
    }

}
