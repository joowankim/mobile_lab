package org.androidtown.lab6_2;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText stu_num, stu_name;
    Button load, save, initialize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stu_num = findViewById(R.id.stuNum);
        stu_name = findViewById(R.id.name);
        load = findViewById(R.id.load);
        save = findViewById(R.id.save);
        initialize = findViewById(R.id.initialize);

        // generate SharedPreferences
        final SharedPreferences settings = getSharedPreferences("my_preferred_choices", Context.MODE_PRIVATE);

        /**
         * @brief loading name and student number from SharedPreferences
         */
        load.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String num = settings.getString("studentNumber", "add please");
                String name = settings.getString("studentName", "add please");

                stu_num.setText(num);
                stu_name.setText(name);
                Toast.makeText(getApplicationContext(), "load", Toast.LENGTH_SHORT).show();
            }
        });

        /**
         * @brief save name and student number into SharedPreferences, only if the user entered something
         */
        save.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String num = stu_num.getText().toString();
                String name = stu_name.getText().toString();

                if(!num.equals("") && !name.equals("")) {
                    SharedPreferences.Editor editor = settings.edit();
                    editor.putString("studentNumber", stu_num.getText().toString());
                    editor.putString("studentName", stu_name.getText().toString());
                    editor.commit();
                    Toast.makeText(getApplicationContext(), "save", Toast.LENGTH_SHORT).show();
                } else {    // if the user entered nothing, it would float toast message
                    if (num.equals("")) Toast.makeText(getApplicationContext(), "enter your number", Toast.LENGTH_SHORT).show();
                    if (name.equals("")) Toast.makeText(getApplicationContext(), "enter your name", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /**
         * @brief clear EditText
         */
        initialize.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                stu_num.setText("");
                stu_name.setText("");
                Toast.makeText(getApplicationContext(), "clear", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
