package org.androidtown.lab4_1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by Kim on 2018-05-10.
 */

public class MyDrawEx extends View {

    // to save the points where touched
    ArrayList<Float[]> point = new ArrayList<>();
    Float x;
    Float y;

    public MyDrawEx(Context c){
        super(c);
    }
    public MyDrawEx(Context c, AttributeSet a){
        super(c, a);
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        Paint paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStrokeWidth(10);
        paint.setAntiAlias(true);
        paint.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawColor(Color.WHITE);
        for(int i=0; i<point.size() - 1; i++) { // to draw the line using the line between ith touched point and i-1th touched point
                                                  // to protect errors by overflow
            if(point.get(i+1)[0] != -1) {   // don't draw a line between ACTION_UP and ACTION_DOWN
                if(point.get(i)[0] == -1) continue;
                canvas.drawLine((float) point.get(i)[0], (float) point.get(i)[1], (float) point.get(i + 1)[0], (float) point.get(i + 1)[1], paint);
            }
        }

    }

    /**
     * @brief react to touch event
     * @param event identifier that classifies touch events by user
     * @return
     */
    public boolean onTouchEvent(MotionEvent event){
        super.onTouchEvent(event);

        if(event.getAction() == MotionEvent.ACTION_DOWN) { // when touch starts, get the location
            x = event.getX();
            y = event.getY();
            point.add(new Float[]{x, y});   // save in the points list

            return true;
        }
        if(event.getAction() == MotionEvent.ACTION_MOVE){   // when the touch location is changed, get the location
            x = event.getX();
            y = event.getY();
            point.add(new Float[]{x, y});   // save in the points list
            this.invalidate();  // to redraw the path of touch points
            return true;
        }
        if(event.getAction() == MotionEvent.ACTION_UP){
            point.add(new Float[]{-1f, -1f});

            return true;
        }
        return false;

    }

}
