package org.androidtown.lab6_1;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button write, clear, read, finish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.txtData);
        write = findViewById(R.id.write);
        clear = findViewById(R.id.clear);
        read = findViewById(R.id.read);
        finish = findViewById(R.id.finish);

        /**
         * @brief write information
         */
        write.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                try {
                    // generate File to write information
                    File sdCard = Environment.getExternalStorageDirectory();
                    File directory = new File(sdCard.getAbsolutePath() + "/MyFiles");

                    directory.mkdirs();
                    File file = new File(directory, "textfile.txt");
                    FileOutputStream fOut = new FileOutputStream(file);
                    OutputStreamWriter osw = new OutputStreamWriter(fOut);
                    // write information into file
                    osw.write(editText.getText().toString());
                    osw.close();
                    Toast.makeText(getApplicationContext(), "Done writing", Toast.LENGTH_SHORT).show();
                } catch(Exception e){
                    Toast.makeText(getApplicationContext(), "can't find file", Toast.LENGTH_SHORT).show();
                }
            }
        });
        /**
         * @brief clear EditText
         */
        clear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                editText.setText("");
                Toast.makeText(getApplicationContext(), "clear", Toast.LENGTH_SHORT).show();
            }
        });
        /**
         * @brief read information from file
         */
        read.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                try {
                    // generate File to read information
                    File sdCard = Environment.getExternalStorageDirectory();
                    File directory = new File(sdCard.getAbsolutePath() + "/MyFiles");

                    directory.mkdirs();
                    File file = new File(directory, "textfile.txt");
                    FileInputStream fIn = new FileInputStream(file);
                    InputStreamReader isr = new InputStreamReader(fIn);

                    // read information from file and initialize bs
                    ByteArrayOutputStream bs = new ByteArrayOutputStream();
                    int i = isr.read();
                    while(i != -1) {
                        bs.write(i);
                        i = isr.read();
                    }

                    // convert bs to string
                    String text = bs.toString();
                    editText.setText(text);

                    Toast.makeText(getApplicationContext(), "Done reading from SD ", Toast.LENGTH_SHORT).show();
                } catch(Exception e){
                    Toast.makeText(getApplicationContext(), "can't find file", Toast.LENGTH_SHORT).show();
                }
            }
        });
        /**
         * @brief finish application
         */
        finish.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(getApplicationContext(), "finish", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
